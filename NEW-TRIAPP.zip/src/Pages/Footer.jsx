import React from "react";
import logo from "./images";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-blue-900 to-blue-600 text-white py-10 px-6">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
        
        {/* Brand & Short Description */}
        <div>
          <h2 className="text-2xl font-bold text-white">
          <img src={logo.HomeLogo} alt="HomeTriangle Logo" className="logo" />
          </h2>
          <p className="mt-3 text-gray-300" style={{marginBottom: "20px"}}>
            Your trusted partner for home services. Find professionals for cleaning, repair, renovation, and more.
          </p>
        </div>

        {/* Contact & Social Media */}
        <div>
          <h3 className="text-lg font-semibold" style={{textAlign:"center", color: "white", marginBottom: "20px"}}>Contact Us</h3>
          <p className="mt-3 text-gray-300" style={{marginBottom: "20px"}}>📧 support@hometriangle.com</p>
          <p className="text-gray-300" style={{marginBottom: "20px"}}>📞 +1 234 567 890</p>
        </div>
      </div>

      {/* Copyright Section */}
      <div className="text-center text-gray-300 text-sm mt-8 border-t border-gray-500 pt-4">
        © {new Date().getFullYear()} HomeTriangle. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
