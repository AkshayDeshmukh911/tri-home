import React, { useState } from "react";
import app from "../supabase"; // Assuming this is where you initialize Firebase
import { getDatabase, ref, set, push } from "firebase/database";
import "./ContactPage.css";

const ContactPage = () => {
  let [name, setName] = useState("");
  let [emailid, setEmailid] = useState("");
  let [subject, setSubject] = useState("");
  let [message, setMessage] = useState("");

  const saveData = async (e) => {
    e.preventDefault(); // Prevent the default form submission
    const db = getDatabase(app);
    const contactFormRef = ref(db, "contactForm"); // Reference to the "contactForm" node
    const newContactRef = push(contactFormRef); // Generate a unique key for the new contact

    set(newContactRef, {
      name: name,
      emailid: emailid,
      subject: subject,
      message: message
    })
      .then(() => {
        alert("Data saved successfully!");
        // Clear the form after successful submission
        setName("");
        setEmailid("");
        setSubject("");
        setMessage("");
      })
      .catch((error) => {
        console.error("Error saving data:", error);
        alert("Sorry, there was an error submitting your message.");
      });
  };

  return (
    <div className="contact-container">
      <h2>Contact Us</h2>
      <p>Need help? Fill out the form below and we’ll get back to you.</p>
      <form className="contact-form" id="contactForm" onSubmit={saveData}>
        {/* ... your input fields with value and onChange ... */}
        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            placeholder="Your Name"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            placeholder="Your Email"
            id="emailid"
            value={emailid}
            onChange={(e) => setEmailid(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Subject</label>
          <input
            type="text"
            placeholder="Subject"
            id="subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Message</label>
          <textarea
            placeholder="Your Message"
            rows="5"
            id="msgContent"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
          ></textarea>
        </div>
        <button type="submit" className="contact-submit">
          Send Message
        </button>
      </form>
    </div>
  );
};

export default ContactPage;
