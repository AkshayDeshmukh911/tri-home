import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h2>Your Bookings</h2>
      <p>No bookings yet.</p>
    </div>
  );
};

export default Dashboard;
