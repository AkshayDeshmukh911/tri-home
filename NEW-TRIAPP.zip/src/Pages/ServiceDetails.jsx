import React from "react";
import { useParams } from "react-router-dom";

const serviceData = {
  1: { name: "Plumbing", details: "We offer top-notch plumbing services." },
  2: { name: "Cleaning", details: "Professional home cleaning service." },
};

const ServiceDetails = () => {
  const { id } = useParams();
  const service = serviceData[id];

  return (
    <div>
      <h2>{service.name}</h2>
      <p>{service.details}</p>
      <button>Book Now</button>
    </div>
  );
};

export default ServiceDetails;
