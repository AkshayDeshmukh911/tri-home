import React, { useState } from "react";
import Img from "./images";
import BookingPage from "./CreateBookingPage";
import "./PersonDetailsModal.css";

const PersonDetailsModal = ({ persons, onClose }) => {
  const [selectedPerson, setSelectedPerson] = useState(null);

  if (!persons || persons.length === 0) return null;

  const handleBookSlot = (person) => {
    setSelectedPerson(person);
  };

  const handleBack = () => {
    setSelectedPerson(null);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="person-modal" onClick={(e) => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}>&times;</button>
        {selectedPerson ? (
          <BookingPage person={selectedPerson} onBack={handleBack} />
        ) : (
          <>
            <h2>Available Experts</h2>
            <div className="person-list">
              {persons.map((person, index) => (
                <div className="person-card" key={index}>
                  <img src={Img[person.image]} alt={person.name} className="person-image" />
                  <h3>{person.name}</h3>
                  <p className="phone"><strong>Phone:</strong> {person.phone}</p>
                  <p className="description">{person.description}</p>
                  <p><strong>Charges:</strong> {person.charges}</p>
                  <p><strong>Schedule:</strong> {person.schedule}</p>
                  <p><strong>Working Hours:</strong> {person.workingHours}</p>
                  <p><strong>Charge Rate:</strong> {person.chargeRate}</p>
                  <button className="book-slot-btn" onClick={() => handleBookSlot(person)}>Book Slot</button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default PersonDetailsModal;
