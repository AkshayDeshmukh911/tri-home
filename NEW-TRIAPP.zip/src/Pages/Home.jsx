import React, { useState, useEffect, useRef } from "react";
import ServiceModal from "./HandymanServices";
import Icons from "./images";
import data from "../data.json";
import "./Home.css";

// Define the available services (keep this as is)
const services = [
  { name: "Salon & Spa Services", icon: Icons.salon },
  { name: "Handyman Services", icon: Icons.Handyman },
  { name: "Appliance Repair", icon: Icons.Appliance },
  { name: "Cleaning & Pest Control", icon: Icons.Cleaning },
  { name: "Mosquito & Safety Net", icon: Icons.SafetyNet },
  { name: "Movers & Storage", icon: Icons.Movers },
  { name: "Renovation & Fabrication", icon: Icons.Renovation }
];

const Home = () => {
  const [selectedService, setSelectedService] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredServices, setFilteredServices] = useState(services);
  const [selectedCity, setSelectedCity] = useState(""); // Store selected city
  const modalRef = useRef(null);

  // Example list of cities, this can be fetched from your data.json if needed
  const cities = ["Mumbai", "Pune", "Kholhapur", "Sangli", "Satara"];

  // Filter services based on search query and selected city
  useEffect(() => {
    const filtered = services.filter(service => {
      const matchesQuery = service.name.toLowerCase().includes(searchQuery.toLowerCase());
      const serviceKey = service.name.replace(/\s+/g, "");
      const serviceCities = data[serviceKey]?.cities || [];

      const matchesCity = !selectedCity || serviceCities.includes(selectedCity);

      return matchesQuery && matchesCity;
    });

    setFilteredServices(filtered);
  }, [searchQuery, selectedCity]);

  const handleServiceClick = (serviceName) => {
    const key = serviceName.replace(/\s+/g, "");
    const serviceData = data[key];
    if (serviceData) {
      setSelectedService(serviceData);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setSelectedService(null);
      }
    };

    if (selectedService) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [selectedService]);

  return (
    <div className="home-container">
      {/* Header Section */}
      <div className="hero-section">
        <h1 style={{marginTop: "10px"}}>Hiring service experts made <span>easy</span></h1>
        <div className="search-bar">
          <select
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            className="city-dropdown"
          >
            <option value="">Select your city</option>
            {cities.map((city, index) => (
              <option key={index} value={city}>
                {city}
              </option>
            ))}
          </select>

          {/* Search bar for services */}
          <input
            type="text"
            placeholder="What service do you need?"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button>🔍</button>
        </div>
      </div>

      {/* Services Section */}
      <div className="services-grid">
        {filteredServices.length > 0 ? (
          filteredServices.map((service, index) => (
            <div
              className="service-card"
              key={index}
              onClick={() => handleServiceClick(service.name)}
            >
              <img src={service.icon} alt={service.name} />
              <p>{service.name}</p>
            </div>
          ))
        ) : (
          <p className="no-results">No matching services found.</p>
        )}
      </div>

      {/* Service Modal */}
      {selectedService && (
        <ServiceModal service={selectedService} onClose={() => setSelectedService(null)} />
      )}

        {/* Video Block */}
        <div className="video-block" style={{marginTop: "30px"}}>
        <h2 style={{marginBottom: "20px"}}>Watch How We Work</h2>
        <div className="video-container">
        <video
  width="100%"
  height="500"
  autoPlay
  muted
  loop
  playsInline
  className="custom-video"
>
  <source
    src="/videos/new_play.mp4"
    type="video/mp4"
  />
  Your browser does not support the video tag.
</video>

        </div>
      </div>
    </div>
  );
};

export default Home;
