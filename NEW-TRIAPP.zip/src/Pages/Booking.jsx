import React, { useState } from "react";

const Booking = () => {
  const [formData, setFormData] = useState({ name: "", phone: "", service: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Service Booked!");
  };

  return (
    <div>
      <h2>Book a Service</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Your Name" onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
        <input type="tel" placeholder="Phone Number" onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
        <select onChange={(e) => setFormData({ ...formData, service: e.target.value })}>
          <option>Select Service</option>
          <option>Plumbing</option>
          <option>Cleaning</option>
        </select>
        <button type="submit">Confirm Booking</button>
      </form>
    </div>
  );
};

export default Booking;
