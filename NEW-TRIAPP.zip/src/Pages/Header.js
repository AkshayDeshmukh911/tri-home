import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Header.css";
import logo from "../assets/blue-white-htr-logo.png"; 
import ondcLogo from "./images";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

    return (
      <div className="header-wrapper">
        <nav className="navbar">
          <div className="container">
            {/* Left Logo */}
            <Link className="navbar-brand" to="/">
              <img src={logo} alt="HomeTriangle Logo" className="logo" />
            </Link>
  
            {/* Mobile Toggle Button */}
            <button
              className="menu-toggle"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              ☰
            </button>
  
            {/* Right Section */}
            <div className={`navbar-links ${isMenuOpen ? "open" : ""}`}>
              <ul>
                <li><Link to="/contact">Contact</Link></li>
                <li><Link to="/dashboard">Dashboard</Link></li>
                <li>
                  <img src={ondcLogo} alt="ONDC Network" className="ondc-logo" />
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
  );
};

export default Header;
