import salon from "../assets/salon.png";
import Handyman from "../assets/handyman.png";
import Appliance from "../assets/appliance.png";
import Cleaning from "../assets/cleaning.png";
import SafetyNet from "../assets/safetyNet.png";
import Movers from "../assets/movers.png";
import Renovation from "../assets/renovations.png";
import Electricion from "../assets/Electricion.png";
import Carpenter from "../assets/carpenter.png";
import Plumber from "../assets/plumber.png";
import Furniture from "../assets/furniture.png";
import Hanger from "../assets/hanger.png";
import Tv from "../assets/tv.png";
import Profile from "../assets/profile.png";
import AC from "../assets/AC.png";
import Gas from "../assets/Gas.png";
import Geyser from "../assets/Geyser.png";
import Refrigerator from "../assets/Refrigerator.png";
import Microwave from "../assets/Microwave.png";
import HomeLogo from "../assets/blue-white-htr-logo.png";

const images = {
    salon,
    Handyman,
    Appliance,
    Cleaning,
    SafetyNet,
    Movers,
    Renovation,
    Electricion,
    Carpenter,
    Plumber,
    Furniture,
    Hanger,
    Tv,
    Profile,
    AC,
    Gas,
    Geyser,
    Refrigerator,
    Microwave,
    HomeLogo
  };
  
  export default images;