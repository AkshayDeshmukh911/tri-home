import React, { useState } from "react";
import "./CreateBookingPage.css";

const BookingPage = ({ person, onBack }) => {
  const [slots, setSlots] = useState([
    { time: "10:00 AM - 11:00 AM", booked: false },
    { time: "11:00 AM - 12:00 PM", booked: false },
    { time: "01:00 PM - 02:00 PM", booked: false },
    // Add more slots as needed
  ]);

  const handleBookSlot = (index) => {
    const newSlots = [...slots];
    newSlots[index].booked = true;
    setSlots(newSlots);
  };

  return (
    <div className="booking-page">
      <button className="back-btn" onClick={onBack}>&larr; Back</button>
      <h2>Book Slot for {person.name}</h2>
      <div className="slots-list">
        {slots.map((slot, index) => (
          <div key={index} className={`slot ${slot.booked ? "booked" : ""}`}>
            <span>{slot.time}</span>
            <button
              className="book-btn"
              onClick={() => handleBookSlot(index)}
              disabled={slot.booked}
            >
              {slot.booked ? "Booked" : "Book Slot"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookingPage;
