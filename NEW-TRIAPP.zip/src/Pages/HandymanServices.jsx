import React, { useState } from "react";
import PersonDetailsModal from "./PersonDetailsModal";
import Img from "./images"
import "./HandymanServices.css";

const ServiceModal = ({ service, onClose }) => {
  const [selectedPersons, setSelectedPersons] = useState([]);

  if (!service) return null;

  // Open person details modal
  const handlePersonClick = (serviceName) => {
    setSelectedPersons(service.persons?.[serviceName] || []);
  };

  // Close person details modal
  const closePersonModal = () => {
    setSelectedPersons([]);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}>&times;</button>
        <h2>{service.title}</h2>

        {service.categories.map((category, index) => (
          <div key={index} className="category-block">
            <h3>{category.name}</h3>
            <div className="service-list">
              {category.items.map((item, i) => (
                <div className="service-item" key={i} onClick={() => handlePersonClick(item.name)}>
                  <img src={Img[item.image]} alt={item.name} />
                  <p>{item.name}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Person Details Modal */}
      {selectedPersons.length > 0 && (
        <PersonDetailsModal persons={selectedPersons} onClose={closePersonModal} />
      )}
    </div>
  );
};

export default ServiceModal;
