import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import Home from "./Pages/Home";
import Services from "./Pages/HandymanServices";
import ServiceDetails from "./Pages/ServiceDetails";
import Booking from "./Pages/Booking";
import Dashboard from "./Pages/Dashboard";
import Header from "./Pages/Header";
import Footer from "./Pages/Footer";
import LoginPage from "./Pages/LoginPage";
import Contact from "./Pages/ContactPage";
import "./styles.css";

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <Router>
      {isLoggedIn && <Header />}
      <Routes>
        <Route path="/" element={
          isLoggedIn ? <Navigate to="/Home" /> : <LoginPage setIsLoggedIn={setIsLoggedIn} />
        } />
        <Route path="/Home" element={isLoggedIn ? <Home /> : <Navigate to="/" />} />
        <Route path="/services" element={isLoggedIn ? <Services /> : <Navigate to="/" />} />
        <Route path="/services/:id" element={isLoggedIn ? <ServiceDetails /> : <Navigate to="/" />} />
        <Route path="/booking" element={isLoggedIn ? <Booking /> : <Navigate to="/" />} />
        <Route path="/dashboard" element={isLoggedIn ? <Dashboard /> : <Navigate to="/" />} />
        <Route path="/contact" element={isLoggedIn ? <Contact/> : <Navigate to="/" />} />
      </Routes>
      {isLoggedIn && <Footer />}
    </Router>
  );
};

export default App;
