import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAWuwHyaVLtSefxvlSruAir02UPXfVTGOg",
  authDomain: "new-hometriangle.firebaseapp.com",
  databaseURL: "https://new-hometriangle-default-rtdb.firebaseio.com/",
  projectId: "new-hometriangle",
  storageBucket: "new-hometriangle.firebasestorage.app",
  messagingSenderId: "730357510396",
  appId: "1:730357510396:web:dd26ad29146d46e78de779"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

  export default app;
