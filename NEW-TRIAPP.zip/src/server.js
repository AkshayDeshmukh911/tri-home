const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 5000;
const SECRET_KEY = "yourSecretKey123";

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'yourpassword',
  database: 'auth_demo'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Signup
app.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;
  db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
    if (err) throw err;
    if (results.length > 0) return res.status(400).json({ error: 'User already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = { name, email, password: hashedPassword };
    db.query('INSERT INTO users SET ?', user, (err, result) => {
      if (err) throw err;
      res.status(200).json({ message: 'Signup successful' });
    });
  });
});

// Login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  db.query('SELECT * FROM users WHERE email = ?', [email], async (err, results) => {
    if (err) throw err;
    if (results.length === 0) return res.status(400).json({ error: 'Invalid credentials' });

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user.id }, SECRET_KEY);
    res.status(200).json({ token });
  });
});

// Fetch available slots
app.get('/slots', (req, res) => {
  db.query('SELECT * FROM slots', (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Book a slot
app.post('/book-slot', (req, res) => {
  const { userId, slotTime } = req.body;
  const slot = { user_id: userId, slot_time: slotTime };
  db.query('INSERT INTO slots SET ?', slot, (err, result) => {
    if (err) throw err;
    res.status(200).json({ message: 'Slot booked successfully' });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
